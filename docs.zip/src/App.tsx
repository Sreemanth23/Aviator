import { useState } from 'react';
import { SpecialIncrementForm } from './components/SpecialIncrementForm';
import { EligibilityChecker } from './components/EligibilityChecker';
import { useOnlineStatus } from './hooks/useLocalStorage';

type TabType = 'generator' | 'checker';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('generator');
  const isOnline = useOnlineStatus();

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Offline Banner */}
      {!isOnline && (
        <div className="bg-yellow-500 text-yellow-900 text-center py-2 text-sm font-medium">
          📴 You are currently offline. All features work offline. Data is saved locally.
        </div>
      )}
      
      {/* Header Banner */}
      <header className="bg-gradient-to-r from-orange-500 via-white to-green-500 py-1">
        <div className="max-w-6xl mx-auto px-4 flex justify-center items-center">
          <span className="text-blue-900 font-bold text-lg">🇮🇳</span>
        </div>
      </header>
      
      {/* Government Header */}
      <div className="bg-blue-900 text-white py-4">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h1 className="text-xl md:text-2xl font-bold">
            Government of Andhra Pradesh
          </h1>
          <p className="text-blue-200 text-sm md:text-base mt-1">
            Revenue Department - Special Increment Document Generator
          </p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-4">
          <nav className="flex gap-1">
            <button
              onClick={() => setActiveTab('generator')}
              className={`px-6 py-3 font-medium text-sm transition-colors ${
                activeTab === 'generator'
                  ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                  : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
              }`}
            >
              📄 Document Generator
            </button>
            <button
              onClick={() => setActiveTab('checker')}
              className={`px-6 py-3 font-medium text-sm transition-colors ${
                activeTab === 'checker'
                  ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                  : 'text-gray-600 hover:text-blue-600 hover:bg-gray-50'
              }`}
            >
              🎯 Eligibility Checker
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="py-6">
        {activeTab === 'generator' && <SpecialIncrementForm />}
        {activeTab === 'checker' && (
          <div className="max-w-4xl mx-auto px-4">
            <EligibilityChecker />
            
            {/* Information Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold text-gray-800 mb-2">📋 Special Increment Types</h3>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500">●</span>
                    <span><strong>6 Years</strong> - Special Grade Post (SGP)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500">●</span>
                    <span><strong>12 Years</strong> - Special Promotion Post Scale IA (SPP-IA)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-500">●</span>
                    <span><strong>18 Years</strong> - Special Promotion Post Scale IB (SPP-IB)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-orange-500">●</span>
                    <span><strong>24 Years</strong> - Special Promotion Post Scale II (SPP-II)</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <h3 className="font-semibold text-gray-800 mb-2">📌 Important Notes</h3>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• EOL days postpone the completion date</li>
                  <li>• Service must be without any promotion</li>
                  <li>• Disciplinary cases may affect eligibility</li>
                  <li>• Verify all details from Service Register</li>
                  <li>• Pay fixation under FR.22(a)(i) & FR.31(2)</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-6 mt-8">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
            <div>
              <h4 className="font-semibold text-white mb-2">About This Tool</h4>
              <p>
                This tool generates Office Notes and Proceedings for Special Increments 
                (6/12/18/24 years) as per G.O.Ms.No.96, Finance (P.C.II) Department, dt.20.05.2011.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-2">Applicable Cadres</h4>
              <ul className="list-disc list-inside">
                <li>Village Revenue Officer (VRO)</li>
                <li>Junior Assistant</li>
                <li>Senior Assistant</li>
                <li>Deputy Tahsildar</li>
                <li>Tahsildar</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-2">References</h4>
              <ul className="text-xs space-y-1">
                <li>G.O.Ms.No.96, Finance (P.C.II) Dept, dt.20.05.2011</li>
                <li>G.O.Ms.No.68, Finance (HRM.V) Dept, Dt: 12.06.2015</li>
                <li>GO.MS.No.1, Finance (PC-TA) Dept, Dt:17.01.2022</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-6 pt-4 text-center text-xs">
            <p>Pay Scales as per RPS 2022 (Revised Pay Scales)</p>
            <p className="mt-1 text-gray-500">
              For official use only. Verify all calculations with Service Register.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
