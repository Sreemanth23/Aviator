import { useState, useEffect } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((prev: T) => T)) => void, () => void] {
  // Get stored value or use initial value
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return initialValue;
    }
  });

  // Update localStorage when value changes
  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  }, [key, storedValue]);

  // Clear function
  const clearValue = () => {
    try {
      window.localStorage.removeItem(key);
      setStoredValue(initialValue);
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  };

  return [storedValue, setStoredValue, clearValue];
}

// Save draft data
export function saveDraft(key: string, data: any): void {
  try {
    const drafts = JSON.parse(localStorage.getItem('si_drafts') || '{}');
    drafts[key] = {
      data,
      savedAt: new Date().toISOString()
    };
    localStorage.setItem('si_drafts', JSON.stringify(drafts));
  } catch (error) {
    console.error('Error saving draft:', error);
  }
}

// Load draft data
export function loadDraft(key: string): any | null {
  try {
    const drafts = JSON.parse(localStorage.getItem('si_drafts') || '{}');
    return drafts[key]?.data || null;
  } catch (error) {
    console.error('Error loading draft:', error);
    return null;
  }
}

// Get all drafts
export function getAllDrafts(): Array<{ key: string; savedAt: string; name: string }> {
  try {
    const drafts = JSON.parse(localStorage.getItem('si_drafts') || '{}');
    return Object.entries(drafts).map(([key, value]: [string, any]) => ({
      key,
      savedAt: value.savedAt,
      name: value.data?.name || 'Unnamed'
    }));
  } catch (error) {
    console.error('Error getting drafts:', error);
    return [];
  }
}

// Delete draft
export function deleteDraft(key: string): void {
  try {
    const drafts = JSON.parse(localStorage.getItem('si_drafts') || '{}');
    delete drafts[key];
    localStorage.setItem('si_drafts', JSON.stringify(drafts));
  } catch (error) {
    console.error('Error deleting draft:', error);
  }
}

// Check if app is offline
export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return isOnline;
}
