import React, { useState } from 'react';
import { IncrementEntry } from '../types';

interface IncrementHistoryTableProps {
  history: IncrementEntry[];
  onChange: (history: IncrementEntry[]) => void;
}

export const IncrementHistoryTable: React.FC<IncrementHistoryTableProps> = ({
  history,
  onChange
}) => {
  const [newEntry, setNewEntry] = useState<Partial<IncrementEntry>>({
    incrementNo: history.length + 1,
    fromPay: 0,
    toPay: 0,
    effectiveDate: '',
    pageNo: '',
    srVolume: 'I',
    remarks: ''
  });

  const handleAddEntry = () => {
    if (newEntry.fromPay && newEntry.toPay && newEntry.effectiveDate) {
      const entry: IncrementEntry = {
        incrementNo: history.length + 1,
        fromPay: Number(newEntry.fromPay),
        toPay: Number(newEntry.toPay),
        effectiveDate: newEntry.effectiveDate || '',
        pageNo: newEntry.pageNo || '',
        srVolume: newEntry.srVolume || 'I',
        remarks: newEntry.remarks
      };
      onChange([...history, entry]);
      setNewEntry({
        incrementNo: history.length + 2,
        fromPay: Number(newEntry.toPay),
        toPay: 0,
        effectiveDate: '',
        pageNo: '',
        srVolume: 'I',
        remarks: ''
      });
    }
  };

  const handleRemoveEntry = (index: number) => {
    const newHistory = history.filter((_, i) => i !== index);
    // Renumber entries
    const renumbered = newHistory.map((entry, i) => ({
      ...entry,
      incrementNo: i + 1
    }));
    onChange(renumbered);
  };

  const handleEntryChange = (index: number, field: keyof IncrementEntry, value: string | number) => {
    const newHistory = [...history];
    newHistory[index] = {
      ...newHistory[index],
      [field]: field === 'fromPay' || field === 'toPay' || field === 'incrementNo' 
        ? Number(value) 
        : value
    };
    onChange(newHistory);
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full border border-gray-300 text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th className="border border-gray-300 px-2 py-1">Inc. No.</th>
            <th className="border border-gray-300 px-2 py-1">From Pay (₹)</th>
            <th className="border border-gray-300 px-2 py-1">To Pay (₹)</th>
            <th className="border border-gray-300 px-2 py-1">Effective Date</th>
            <th className="border border-gray-300 px-2 py-1">Page No.</th>
            <th className="border border-gray-300 px-2 py-1">SR Vol.</th>
            <th className="border border-gray-300 px-2 py-1">Remarks</th>
            <th className="border border-gray-300 px-2 py-1">Action</th>
          </tr>
        </thead>
        <tbody>
          {history.map((entry, index) => (
            <tr key={index} className="hover:bg-gray-50">
              <td className="border border-gray-300 px-2 py-1 text-center">
                {entry.incrementNo}
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="number"
                  value={entry.fromPay}
                  onChange={(e) => handleEntryChange(index, 'fromPay', e.target.value)}
                  className="w-24 px-1 py-0.5 border rounded text-right"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="number"
                  value={entry.toPay}
                  onChange={(e) => handleEntryChange(index, 'toPay', e.target.value)}
                  className="w-24 px-1 py-0.5 border rounded text-right"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="date"
                  value={entry.effectiveDate}
                  onChange={(e) => handleEntryChange(index, 'effectiveDate', e.target.value)}
                  className="px-1 py-0.5 border rounded"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={entry.pageNo}
                  onChange={(e) => handleEntryChange(index, 'pageNo', e.target.value)}
                  className="w-16 px-1 py-0.5 border rounded"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <select
                  value={entry.srVolume}
                  onChange={(e) => handleEntryChange(index, 'srVolume', e.target.value)}
                  className="px-1 py-0.5 border rounded"
                >
                  <option value="I">I</option>
                  <option value="II">II</option>
                  <option value="III">III</option>
                </select>
              </td>
              <td className="border border-gray-300 px-2 py-1">
                <input
                  type="text"
                  value={entry.remarks || ''}
                  onChange={(e) => handleEntryChange(index, 'remarks', e.target.value)}
                  placeholder="e.g., Revised Increment"
                  className="w-32 px-1 py-0.5 border rounded text-xs"
                />
              </td>
              <td className="border border-gray-300 px-2 py-1 text-center">
                <button
                  onClick={() => handleRemoveEntry(index)}
                  className="text-red-600 hover:text-red-800 px-2 py-1"
                  title="Remove"
                >
                  ✕
                </button>
              </td>
            </tr>
          ))}
          {/* Add new entry row */}
          <tr className="bg-blue-50">
            <td className="border border-gray-300 px-2 py-1 text-center">
              {history.length + 1}
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <input
                type="number"
                value={newEntry.fromPay || ''}
                onChange={(e) => setNewEntry({ ...newEntry, fromPay: Number(e.target.value) })}
                placeholder="From"
                className="w-24 px-1 py-0.5 border rounded text-right"
              />
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <input
                type="number"
                value={newEntry.toPay || ''}
                onChange={(e) => setNewEntry({ ...newEntry, toPay: Number(e.target.value) })}
                placeholder="To"
                className="w-24 px-1 py-0.5 border rounded text-right"
              />
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <input
                type="date"
                value={newEntry.effectiveDate}
                onChange={(e) => setNewEntry({ ...newEntry, effectiveDate: e.target.value })}
                className="px-1 py-0.5 border rounded"
              />
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <input
                type="text"
                value={newEntry.pageNo}
                onChange={(e) => setNewEntry({ ...newEntry, pageNo: e.target.value })}
                placeholder="Page"
                className="w-16 px-1 py-0.5 border rounded"
              />
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <select
                value={newEntry.srVolume}
                onChange={(e) => setNewEntry({ ...newEntry, srVolume: e.target.value })}
                className="px-1 py-0.5 border rounded"
              >
                <option value="I">I</option>
                <option value="II">II</option>
                <option value="III">III</option>
              </select>
            </td>
            <td className="border border-gray-300 px-2 py-1">
              <input
                type="text"
                value={newEntry.remarks || ''}
                onChange={(e) => setNewEntry({ ...newEntry, remarks: e.target.value })}
                placeholder="Remarks"
                className="w-32 px-1 py-0.5 border rounded text-xs"
              />
            </td>
            <td className="border border-gray-300 px-2 py-1 text-center">
              <button
                onClick={handleAddEntry}
                className="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700 text-xs"
              >
                Add
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      
      <p className="text-xs text-gray-500 mt-2">
        * Add increment history entries from the Service Register. Include all increments from joining date.
      </p>
    </div>
  );
};
