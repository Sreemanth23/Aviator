import React, { useState } from 'react';
import { Cadre } from '../types';
import { RPS2022_SCALES, RPS2022_PAY_MATRIX } from '../data/payScales';

interface PayScaleReferenceProps {
  cadre: Cadre;
}

export const PayScaleReference: React.FC<PayScaleReferenceProps> = ({ cadre }) => {
  const [expanded, setExpanded] = useState(false);
  const scales = RPS2022_SCALES[cadre];
  const matrix = RPS2022_PAY_MATRIX[cadre];

  return (
    <div className="bg-gray-50 border rounded-lg p-4">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center justify-between w-full text-left"
      >
        <h4 className="font-medium text-gray-800">
          📊 Pay Scale Reference for {cadre}
        </h4>
        <span className="text-gray-500">{expanded ? '▼' : '►'}</span>
      </button>

      {expanded && (
        <div className="mt-4 space-y-4 text-sm">
          <div>
            <h5 className="font-medium text-blue-700 mb-1">Normal Scale (RPS 2022)</h5>
            <p className="text-gray-600 break-words">{scales.normal.scaleString}</p>
          </div>

          <div>
            <h5 className="font-medium text-green-700 mb-1">Special Grade Scale (6 Years)</h5>
            <p className="text-gray-600 break-words">{scales.special.scaleString}</p>
          </div>

          <div>
            <h5 className="font-medium text-purple-700 mb-1">SPP-IA Scale (12 Years)</h5>
            <p className="text-gray-600 break-words">{scales.sppIA.scaleString}</p>
          </div>

          <div className="border-t pt-4">
            <h5 className="font-medium text-gray-700 mb-2">Pay Matrix (Quick Reference)</h5>
            <div className="grid grid-cols-5 md:grid-cols-8 gap-1 text-xs">
              {matrix.slice(0, 24).map((pay, idx) => (
                <div
                  key={idx}
                  className="bg-white border rounded px-2 py-1 text-center"
                >
                  ₹{pay.toLocaleString('en-IN')}
                </div>
              ))}
              {matrix.length > 24 && (
                <div className="col-span-full text-gray-500 text-center">
                  ... and {matrix.length - 24} more stages
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Quick Pay Lookup Component
export const PayLookup: React.FC<{ cadre: Cadre }> = ({ cadre }) => {
  const [inputPay, setInputPay] = useState('');
  const [result, setResult] = useState<{
    found: boolean;
    index?: number;
    nextPay?: number;
    increment?: number;
  } | null>(null);

  const matrix = RPS2022_PAY_MATRIX[cadre];

  const handleLookup = () => {
    const pay = parseInt(inputPay);
    const index = matrix.indexOf(pay);

    if (index !== -1) {
      setResult({
        found: true,
        index: index + 1,
        nextPay: matrix[index + 1] || pay,
        increment: matrix[index + 1] ? matrix[index + 1] - pay : 0
      });
    } else {
      // Find nearest
      let nearestIndex = -1;
      for (let i = 0; i < matrix.length; i++) {
        if (matrix[i] >= pay) {
          nearestIndex = i;
          break;
        }
      }
      setResult({
        found: false,
        index: nearestIndex !== -1 ? nearestIndex + 1 : undefined,
        nextPay: nearestIndex !== -1 ? matrix[nearestIndex] : undefined
      });
    }
  };

  return (
    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
      <h4 className="font-medium text-blue-800 mb-3">🔍 Quick Pay Lookup</h4>
      <div className="flex gap-2">
        <input
          type="number"
          value={inputPay}
          onChange={(e) => setInputPay(e.target.value)}
          placeholder="Enter current pay"
          className="flex-1 px-3 py-2 border rounded-md text-sm"
        />
        <button
          onClick={handleLookup}
          className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
        >
          Lookup
        </button>
      </div>

      {result && (
        <div className="mt-3 text-sm">
          {result.found ? (
            <div className="space-y-1">
              <p className="text-green-700">
                ✓ Pay found at stage {result.index}
              </p>
              <p>
                Next increment: ₹{result.nextPay?.toLocaleString('en-IN')}/-
                {result.increment ? ` (+₹${result.increment.toLocaleString('en-IN')})` : ''}
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <p className="text-yellow-700">
                ⚠ Exact pay not found in matrix
              </p>
              {result.nextPay && (
                <p>Nearest higher stage: ₹{result.nextPay.toLocaleString('en-IN')}/-</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
