import React from 'react';

interface DocumentPreviewProps {
  title: string;
  content: string;
  onDownload: () => void;
  onClose?: () => void;
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({
  title,
  content,
  onDownload,
  onClose
}) => {
  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    alert('Content copied to clipboard!');
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>${title}</title>
          <style>
            body {
              font-family: 'Times New Roman', Times, serif;
              font-size: 12pt;
              line-height: 1.5;
              margin: 1in;
              white-space: pre-wrap;
              word-wrap: break-word;
            }
          </style>
        </head>
        <body>${content.replace(/\n/g, '<br>')}</body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="bg-gray-800 text-white px-4 py-3 flex justify-between items-center">
        <h3 className="font-semibold">{title}</h3>
        <div className="flex gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-1 bg-gray-600 hover:bg-gray-500 rounded text-sm"
            title="Copy to Clipboard"
          >
            📋 Copy
          </button>
          <button
            onClick={handlePrint}
            className="px-3 py-1 bg-gray-600 hover:bg-gray-500 rounded text-sm"
            title="Print"
          >
            🖨️ Print
          </button>
          <button
            onClick={onDownload}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-500 rounded text-sm"
            title="Download as Word"
          >
            📥 Download Word
          </button>
          {onClose && (
            <button
              onClick={onClose}
              className="px-3 py-1 bg-red-600 hover:bg-red-500 rounded text-sm"
              title="Close"
            >
              ✕
            </button>
          )}
        </div>
      </div>
      <div className="p-4 max-h-[70vh] overflow-y-auto">
        <pre className="font-serif text-sm whitespace-pre-wrap leading-relaxed">
          {content}
        </pre>
      </div>
    </div>
  );
};
