import React, { useState } from 'react';
import { IncrementType } from '../types';
import { formatDate, addYears, addDays, daysBetween } from '../utils/dateUtils';

interface EligibilityResult {
  isEligible: boolean;
  eligibleFor: IncrementType | null;
  sixYearsDate: string;
  twelveYearsDate: string;
  eighteenYearsDate: string;
  twentyFourYearsDate: string;
  yearsCompleted: number;
  daysRemaining: number;
  message: string;
}

export const EligibilityChecker: React.FC = () => {
  const [joiningDate, setJoiningDate] = useState('');
  const [joiningSession, setJoiningSession] = useState<'FN' | 'AN'>('FN');
  const [eolDays, setEolDays] = useState(0);
  const [hasDisciplinaryCase, setHasDisciplinaryCase] = useState(false);
  const [previousIncrement, setPreviousIncrement] = useState<'none' | '6' | '12' | '18'>('none');
  const [result, setResult] = useState<EligibilityResult | null>(null);

  const checkEligibility = () => {
    if (!joiningDate) {
      alert('Please enter the joining date');
      return;
    }

    const today = new Date();
    let startDate = new Date(joiningDate);
    
    // Adjust for AN joining
    if (joiningSession === 'AN') {
      startDate = addDays(startDate, 1);
    }

    // Calculate milestone dates considering EOL
    const sixYearsDate = addDays(addYears(startDate, 6), eolDays);
    const twelveYearsDate = addDays(addYears(startDate, 12), eolDays);
    const eighteenYearsDate = addDays(addYears(startDate, 18), eolDays);
    const twentyFourYearsDate = addDays(addYears(startDate, 24), eolDays);

    // Calculate years completed
    const totalDays = daysBetween(startDate, today);
    const effectiveDays = totalDays - eolDays;
    const yearsCompleted = Math.floor(effectiveDays / 365);

    // Determine eligibility based on previous increment
    let eligibleFor: IncrementType | null = null;
    let message = '';
    let daysRemaining = 0;

    if (hasDisciplinaryCase) {
      message = '⚠️ Disciplinary case is pending. Eligibility may be affected. Please verify with competent authority.';
    }

    switch (previousIncrement) {
      case 'none':
        if (yearsCompleted >= 6 && today >= sixYearsDate) {
          eligibleFor = '6';
          message = '✅ Eligible for 6 Years Special Grade Post (SGP)';
        } else {
          daysRemaining = daysBetween(today, sixYearsDate);
          message = `⏳ Not yet eligible. ${daysRemaining} days remaining for 6 Years increment.`;
        }
        break;

      case '6':
        if (yearsCompleted >= 12 && today >= twelveYearsDate) {
          eligibleFor = '12';
          message = '✅ Eligible for 12 Years Special Promotion Post Scale IA (SPP-IA)';
        } else {
          daysRemaining = daysBetween(today, twelveYearsDate);
          message = `⏳ Not yet eligible. ${daysRemaining} days remaining for 12 Years increment.`;
        }
        break;

      case '12':
        if (yearsCompleted >= 18 && today >= eighteenYearsDate) {
          eligibleFor = '18';
          message = '✅ Eligible for 18 Years Special Promotion Post Scale IB (SPP-IB)';
        } else {
          daysRemaining = daysBetween(today, eighteenYearsDate);
          message = `⏳ Not yet eligible. ${daysRemaining} days remaining for 18 Years increment.`;
        }
        break;

      case '18':
        if (yearsCompleted >= 24 && today >= twentyFourYearsDate) {
          eligibleFor = '24';
          message = '✅ Eligible for 24 Years Special Promotion Post Scale II (SPP-II)';
        } else {
          daysRemaining = daysBetween(today, twentyFourYearsDate);
          message = `⏳ Not yet eligible. ${daysRemaining} days remaining for 24 Years increment.`;
        }
        break;
    }

    if (hasDisciplinaryCase) {
      message += ' ⚠️ Note: Disciplinary case pending - verify eligibility with competent authority.';
    }

    setResult({
      isEligible: eligibleFor !== null,
      eligibleFor,
      sixYearsDate: sixYearsDate.toISOString().split('T')[0],
      twelveYearsDate: twelveYearsDate.toISOString().split('T')[0],
      eighteenYearsDate: eighteenYearsDate.toISOString().split('T')[0],
      twentyFourYearsDate: twentyFourYearsDate.toISOString().split('T')[0],
      yearsCompleted,
      daysRemaining,
      message
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        <span>🎯</span>
        <span>Eligibility Checker</span>
      </h2>
      
      <p className="text-sm text-gray-600 mb-6">
        Check which special increment an employee is eligible for based on their service details.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Date of Joining in Current Cadre *
          </label>
          <input
            type="date"
            value={joiningDate}
            onChange={(e) => setJoiningDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Joining Session
          </label>
          <div className="flex gap-4 mt-2">
            <label className="flex items-center">
              <input
                type="radio"
                checked={joiningSession === 'FN'}
                onChange={() => setJoiningSession('FN')}
                className="mr-2"
              />
              Forenoon (FN)
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                checked={joiningSession === 'AN'}
                onChange={() => setJoiningSession('AN')}
                className="mr-2"
              />
              Afternoon (AN)
            </label>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Previous Special Increment Availed
          </label>
          <select
            value={previousIncrement}
            onChange={(e) => setPreviousIncrement(e.target.value as any)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="none">None - First time applicant</option>
            <option value="6">6 Years (SGP) - Already availed</option>
            <option value="12">12 Years (SPP-IA) - Already availed</option>
            <option value="18">18 Years (SPP-IB) - Already availed</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            EOL Days (if any)
          </label>
          <input
            type="number"
            value={eolDays}
            onChange={(e) => setEolDays(parseInt(e.target.value) || 0)}
            min="0"
            placeholder="0"
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
        </div>

        <div className="md:col-span-2">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={hasDisciplinaryCase}
              onChange={(e) => setHasDisciplinaryCase(e.target.checked)}
              className="mr-2"
            />
            <span className="text-sm text-gray-700">Pending disciplinary case</span>
          </label>
        </div>
      </div>

      <button
        onClick={checkEligibility}
        className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
      >
        Check Eligibility
      </button>

      {result && (
        <div className={`mt-6 p-4 rounded-lg ${result.isEligible ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'}`}>
          <p className={`font-medium ${result.isEligible ? 'text-green-800' : 'text-yellow-800'}`}>
            {result.message}
          </p>
          
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="bg-white p-3 rounded border">
              <p className="text-gray-500 text-xs">6 Years Date</p>
              <p className="font-medium">{formatDate(result.sixYearsDate)}</p>
            </div>
            <div className="bg-white p-3 rounded border">
              <p className="text-gray-500 text-xs">12 Years Date</p>
              <p className="font-medium">{formatDate(result.twelveYearsDate)}</p>
            </div>
            <div className="bg-white p-3 rounded border">
              <p className="text-gray-500 text-xs">18 Years Date</p>
              <p className="font-medium">{formatDate(result.eighteenYearsDate)}</p>
            </div>
            <div className="bg-white p-3 rounded border">
              <p className="text-gray-500 text-xs">24 Years Date</p>
              <p className="font-medium">{formatDate(result.twentyFourYearsDate)}</p>
            </div>
          </div>

          <p className="mt-4 text-xs text-gray-600">
            * Service completed: {result.yearsCompleted} years
            {result.daysRemaining > 0 && ` | Days remaining for next increment: ${result.daysRemaining}`}
          </p>
        </div>
      )}
    </div>
  );
};
