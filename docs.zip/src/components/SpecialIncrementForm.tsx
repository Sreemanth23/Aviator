import React, { useState, useEffect } from 'react';
import { EmployeeData, Cadre, Gender, IncrementType, IncrementEntry } from '../types';
import { FormInput, FormSelect, FormRadioGroup, FormCheckbox, FormTextarea } from './FormInput';
import { IncrementHistoryTable } from './IncrementHistoryTable';
import { DocumentPreview } from './DocumentPreview';
import { PayScaleReference, PayLookup } from './PayScaleReference';
import { generateOfficeNote, generateProceedings, downloadAsWord } from '../utils/documentGenerator';
import { 
  calculateCompletionDate, 
  calculateFixedPay, 
  getIncrementTypeDescription,
  generateFutureIncrements,
  getScaleStrings
} from '../utils/incrementCalculations';
import { formatDate } from '../utils/dateUtils';
import { useLocalStorage, saveDraft, loadDraft, getAllDrafts, deleteDraft, useOnlineStatus } from '../hooks/useLocalStorage';

const CADRE_OPTIONS = [
  { value: 'Village Revenue Officer', label: 'Village Revenue Officer (VRO)' },
  { value: 'Junior Assistant', label: 'Junior Assistant' },
  { value: 'Senior Assistant', label: 'Senior Assistant' },
  { value: 'Deputy Tahsildar', label: 'Deputy Tahsildar' },
  { value: 'Tahsildar', label: 'Tahsildar' },
];

const INCREMENT_OPTIONS = [
  { value: '6', label: '6 Years - Special Grade Post (SGP)' },
  { value: '12', label: '12 Years - Special Promotion Post IA (SPP-IA)' },
  { value: '18', label: '18 Years - Special Promotion Post IB (SPP-IB)' },
  { value: '24', label: '24 Years - Special Promotion Post II (SPP-II)' },
];

const DISTRICT_OPTIONS = [
  { value: 'SPS Nellore', label: 'SPS Nellore' },
  { value: 'SPSR Nellore', label: 'SPSR Nellore' },
  { value: 'Tirupati', label: 'Tirupati' },
  { value: 'Chittoor', label: 'Chittoor' },
  { value: 'Kadapa', label: 'Kadapa' },
  { value: 'Anantapur', label: 'Anantapur' },
  { value: 'Kurnool', label: 'Kurnool' },
  { value: 'Prakasam', label: 'Prakasam' },
  { value: 'Guntur', label: 'Guntur' },
  { value: 'Krishna', label: 'Krishna' },
  { value: 'West Godavari', label: 'West Godavari' },
  { value: 'East Godavari', label: 'East Godavari' },
  { value: 'Visakhapatnam', label: 'Visakhapatnam' },
  { value: 'Vizianagaram', label: 'Vizianagaram' },
  { value: 'Srikakulam', label: 'Srikakulam' },
];

interface FormData extends Partial<EmployeeData> {
  incrementType: IncrementType;
}

const initialFormData: FormData = {
  incrementType: '6',
  name: '',
  gender: 'male',
  cadre: 'Village Revenue Officer',
  grade: 'I',
  village: '',
  office: 'Tahsildar',
  mandal: '',
  district: 'SPS Nellore',
  joiningDate: '',
  joiningSession: 'FN',
  appointmentOrderNo: '',
  appointmentOrderDate: '',
  initialPay: 0,
  currentPay: 0,
  prcVersion: '2022',
  incrementHistory: [],
  hasEOL: false,
  eolDays: 0,
  hasDisciplinaryCase: false,
  disciplinaryCaseDetails: '',
  proposalLetterNo: '',
  proposalLetterDate: '',
  collectorName: 'SRI HIMANSHU SHUKLA, I.A.S.',
  collectorDesignation: 'I.A.S.',
  jointCollectorName: '',
  droName: '',
  approvedByName: '',
  approvedDate: '',
};

// Sample data for testing
const sampleDataVRO: FormData = {
  incrementType: '6',
  name: 'A. Haribabulu',
  gender: 'male',
  cadre: 'Village Revenue Officer',
  grade: 'I',
  village: 'Gangapatram-2',
  office: 'Tahsildar',
  mandal: 'Indukurpet',
  district: 'SPS Nellore',
  joiningDate: '2018-01-27',
  joiningSession: 'AN',
  appointmentOrderNo: 'Rc.A3/4102/2018',
  appointmentOrderDate: '2018-01-24',
  initialPay: 25220,
  currentPay: 29980,
  prcVersion: '2022',
  incrementHistory: [],
  hasEOL: false,
  eolDays: 0,
  hasDisciplinaryCase: false,
  disciplinaryCaseDetails: '',
  proposalLetterNo: 'Tahsildar, Indukurpet, letter in Rc.A.277/2025',
  proposalLetterDate: '2025-09-29',
  collectorName: 'SRI HIMANSHU SHUKLA, I.A.S.',
  collectorDesignation: 'I.A.S.',
  jointCollectorName: '',
  droName: '',
  approvedByName: '',
  approvedDate: '',
};

const sampleDataDeputyTahsildar: FormData = {
  incrementType: '12',
  name: 'K. Srinivasulu',
  gender: 'male',
  cadre: 'Deputy Tahsildar',
  grade: '',
  village: '',
  office: 'Tahsildar',
  mandal: 'Chilakuru',
  district: 'SPS Nellore',
  joiningDate: '2013-06-14',
  joiningSession: 'FN',
  appointmentOrderNo: 'Rc.No.A5/02/2013',
  appointmentOrderDate: '2013-06-14',
  initialPay: 44570,
  currentPay: 115500,
  prcVersion: '2022',
  incrementHistory: [],
  hasEOL: false,
  eolDays: 0,
  hasDisciplinaryCase: false,
  disciplinaryCaseDetails: '',
  proposalLetterNo: 'R/o of Sri K Srinivasulu, Deputy Tahsildar',
  proposalLetterDate: '2025-06-01',
  collectorName: 'SRI HIMANSHU SHUKLA, I.A.S.',
  collectorDesignation: 'I.A.S.',
  jointCollectorName: 'SRI MOGILI VENKATESWARLU., I.A.S.',
  droName: '',
  approvedByName: '',
  approvedDate: '',
};

export const SpecialIncrementForm: React.FC = () => {
  // Use localStorage for auto-save
  const [savedFormData, setSavedFormData] = useLocalStorage<FormData>('si_current_form', initialFormData);
  const [formData, setFormData] = useState<FormData>(savedFormData);
  const [step, setStep] = useState(1);
  const [showSampleMenu, setShowSampleMenu] = useState(false);
  const [showDraftsMenu, setShowDraftsMenu] = useState(false);
  const [drafts, setDrafts] = useState<Array<{ key: string; savedAt: string; name: string }>>([]);
  const isOnline = useOnlineStatus();
  
  const [calculatedData, setCalculatedData] = useState<{
    completionDate: string;
    effectiveDate: string;
    fixedPay: number;
    futureIncrements: Array<{ presentPay: number; futurePay: number; date: string }>;
    currentScale: string;
    newScale: string;
  } | null>(null);
  const [showOfficeNote, setShowOfficeNote] = useState(false);
  const [showProceedings, setShowProceedings] = useState(false);
  const [officeNoteContent, setOfficeNoteContent] = useState('');
  const [proceedingsContent, setProceedingsContent] = useState('');

  // Auto-save form data to localStorage
  useEffect(() => {
    setSavedFormData(formData);
  }, [formData, setSavedFormData]);

  // Load drafts list
  useEffect(() => {
    setDrafts(getAllDrafts());
  }, []);

  // Save current form as draft
  const handleSaveDraft = () => {
    const draftKey = `draft_${Date.now()}`;
    saveDraft(draftKey, formData);
    setDrafts(getAllDrafts());
    alert('Draft saved successfully!');
  };

  // Load draft
  const handleLoadDraft = (key: string) => {
    const draftData = loadDraft(key);
    if (draftData) {
      setFormData(draftData);
      setShowDraftsMenu(false);
      setStep(1);
    }
  };

  // Delete draft
  const handleDeleteDraft = (key: string) => {
    if (confirm('Are you sure you want to delete this draft?')) {
      deleteDraft(key);
      setDrafts(getAllDrafts());
    }
  };

  // Update office based on cadre
  useEffect(() => {
    if (formData.cadre === 'Village Revenue Officer') {
      setFormData(prev => ({ ...prev, office: 'Tahsildar' }));
    } else if (formData.cadre === 'Deputy Tahsildar' || formData.cadre === 'Tahsildar') {
      setFormData(prev => ({ ...prev, office: 'Tahsildar' }));
    }
  }, [formData.cadre]);

  // Calculate details when relevant fields change
  useEffect(() => {
    if (formData.joiningDate && formData.currentPay && formData.cadre) {
      try {
        const years = parseInt(formData.incrementType);
        const { completionDate, effectiveDate } = calculateCompletionDate(
          formData.joiningDate,
          formData.joiningSession || 'FN',
          years,
          formData.eolDays || 0
        );

        const fixedPay = calculateFixedPay(
          formData.currentPay,
          formData.cadre as Cadre,
          formData.incrementType
        );

        const incrementMonth = new Date(formData.joiningDate).getMonth() + 1;
        const futureIncrements = generateFutureIncrements(
          fixedPay,
          effectiveDate,
          formData.cadre as Cadre,
          incrementMonth,
          5
        );

        const { currentScale, newScale } = getScaleStrings(
          formData.cadre as Cadre,
          formData.incrementType
        );

        setCalculatedData({
          completionDate,
          effectiveDate,
          fixedPay,
          futureIncrements,
          currentScale,
          newScale
        });
      } catch (error) {
        console.error('Calculation error:', error);
      }
    }
  }, [
    formData.joiningDate,
    formData.joiningSession,
    formData.currentPay,
    formData.cadre,
    formData.incrementType,
    formData.eolDays
  ]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : 
              type === 'number' ? (value === '' ? 0 : Number(value)) : 
              value
    }));
  };

  const handleIncrementHistoryChange = (history: IncrementEntry[]) => {
    setFormData(prev => ({ ...prev, incrementHistory: history }));
    
    // Update current pay based on latest increment
    if (history.length > 0) {
      const latestPay = history[history.length - 1].toPay;
      setFormData(prev => ({ ...prev, currentPay: latestPay }));
    }
  };

  const generateDocuments = () => {
    const employeeData: EmployeeData = {
      name: formData.name || '',
      gender: formData.gender as Gender,
      cadre: formData.cadre as Cadre,
      grade: formData.grade,
      village: formData.village,
      office: formData.office || '',
      mandal: formData.mandal || '',
      district: formData.district || '',
      appointmentDate: formData.joiningDate || '',
      appointmentOrderNo: formData.appointmentOrderNo || '',
      appointmentOrderDate: formData.appointmentOrderDate || '',
      joiningDate: formData.joiningDate || '',
      joiningSession: formData.joiningSession || 'FN',
      initialPay: formData.initialPay || 0,
      currentPay: formData.currentPay || 0,
      prcVersion: formData.prcVersion || '2022',
      incrementHistory: formData.incrementHistory || [],
      hasEOL: formData.hasEOL || false,
      eolDays: formData.eolDays,
      eolFromDate: formData.eolFromDate,
      eolToDate: formData.eolToDate,
      hasDisciplinaryCase: formData.hasDisciplinaryCase || false,
      disciplinaryCaseDetails: formData.disciplinaryCaseDetails,
      proposalLetterNo: formData.proposalLetterNo || '',
      proposalLetterDate: formData.proposalLetterDate || '',
      approvedByName: formData.approvedByName || '',
      approvedByDesignation: '',
      approvedDate: formData.approvedDate || '',
      collectorName: formData.collectorName || '',
      collectorDesignation: formData.collectorDesignation || '',
      jointCollectorName: formData.jointCollectorName || '',
      droName: formData.droName || '',
    };

    const officeNote = generateOfficeNote(employeeData, formData.incrementType);
    const proceedings = generateProceedings(employeeData, formData.incrementType);

    setOfficeNoteContent(officeNote);
    setProceedingsContent(proceedings);
    setShowOfficeNote(true);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="bg-blue-50 p-4 rounded-lg">
        <h3 className="font-semibold text-blue-800 mb-2">Step 1: Basic Information</h3>
        <p className="text-sm text-blue-600">Select the increment type and enter employee details.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormSelect
          label="Increment Type"
          name="incrementType"
          value={formData.incrementType}
          onChange={handleInputChange}
          options={INCREMENT_OPTIONS}
          required
        />

        <FormSelect
          label="Cadre"
          name="cadre"
          value={formData.cadre || ''}
          onChange={handleInputChange}
          options={CADRE_OPTIONS}
          required
        />

        <FormInput
          label="Employee Name"
          name="name"
          value={formData.name || ''}
          onChange={handleInputChange}
          placeholder="e.g., T. Mallikarjuna"
          required
        />

        <FormRadioGroup
          label="Gender"
          name="gender"
          value={formData.gender || 'male'}
          onChange={handleInputChange}
          options={[
            { value: 'male', label: 'Male (Sri)' },
            { value: 'female', label: 'Female (Smt)' }
          ]}
          required
        />

        {(formData.cadre === 'Village Revenue Officer') && (
          <>
            <FormInput
              label="Grade"
              name="grade"
              value={formData.grade || ''}
              onChange={handleInputChange}
              placeholder="e.g., I"
            />
            <FormInput
              label="Village"
              name="village"
              value={formData.village || ''}
              onChange={handleInputChange}
              placeholder="e.g., Isakapalli-I Village"
            />
          </>
        )}

        <FormInput
          label="Office"
          name="office"
          value={formData.office || ''}
          onChange={handleInputChange}
          placeholder="e.g., Tahsildar"
          required
        />

        <FormInput
          label="Mandal"
          name="mandal"
          value={formData.mandal || ''}
          onChange={handleInputChange}
          placeholder="e.g., Allur"
          required
        />

        <FormSelect
          label="District"
          name="district"
          value={formData.district || ''}
          onChange={handleInputChange}
          options={DISTRICT_OPTIONS}
          required
        />
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="bg-green-50 p-4 rounded-lg">
        <h3 className="font-semibold text-green-800 mb-2">Step 2: Service Details</h3>
        <p className="text-sm text-green-600">Enter appointment and service details from Service Register.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormInput
          label="Appointment Order No."
          name="appointmentOrderNo"
          value={formData.appointmentOrderNo || ''}
          onChange={handleInputChange}
          placeholder="e.g., Rc.A3/1509/2011"
          required
        />

        <FormInput
          label="Appointment Order Date"
          name="appointmentOrderDate"
          type="date"
          value={formData.appointmentOrderDate || ''}
          onChange={handleInputChange}
          required
        />

        <FormInput
          label="Date of Joining in Current Cadre"
          name="joiningDate"
          type="date"
          value={formData.joiningDate || ''}
          onChange={handleInputChange}
          required
        />

        <FormRadioGroup
          label="Joining Session"
          name="joiningSession"
          value={formData.joiningSession || 'FN'}
          onChange={handleInputChange}
          options={[
            { value: 'FN', label: 'Forenoon (FN)' },
            { value: 'AN', label: 'Afternoon (AN)' }
          ]}
          required
        />

        <FormInput
          label="Initial Pay at Joining (RPS 2022)"
          name="initialPay"
          type="number"
          value={formData.initialPay || ''}
          onChange={handleInputChange}
          placeholder="e.g., 25220"
          required
        />

        <FormInput
          label="Current Pay (RPS 2022)"
          name="currentPay"
          type="number"
          value={formData.currentPay || ''}
          onChange={handleInputChange}
          placeholder="e.g., 36560"
          required
        />
      </div>

      <div className="border-t pt-4">
        <h4 className="font-medium mb-3">EOL (Extraordinary Leave) Details</h4>
        <FormCheckbox
          label="Employee has availed EOL"
          name="hasEOL"
          checked={formData.hasEOL || false}
          onChange={handleInputChange}
        />
        
        {formData.hasEOL && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3 pl-6">
            <FormInput
              label="EOL From Date"
              name="eolFromDate"
              type="date"
              value={formData.eolFromDate || ''}
              onChange={handleInputChange}
            />
            <FormInput
              label="EOL To Date"
              name="eolToDate"
              type="date"
              value={formData.eolToDate || ''}
              onChange={handleInputChange}
            />
            <FormInput
              label="Total EOL Days"
              name="eolDays"
              type="number"
              value={formData.eolDays || ''}
              onChange={handleInputChange}
              placeholder="e.g., 112"
            />
          </div>
        )}
      </div>

      <div className="border-t pt-4">
        <h4 className="font-medium mb-3">Disciplinary Cases</h4>
        <FormCheckbox
          label="Pending disciplinary cases against the employee"
          name="hasDisciplinaryCase"
          checked={formData.hasDisciplinaryCase || false}
          onChange={handleInputChange}
        />
        
        {formData.hasDisciplinaryCase && (
          <div className="mt-3 pl-6">
            <FormTextarea
              label="Disciplinary Case Details"
              name="disciplinaryCaseDetails"
              value={formData.disciplinaryCaseDetails || ''}
              onChange={handleInputChange}
              placeholder="Enter details about the disciplinary case, any punishment imposed, appeal status, etc."
              rows={4}
            />
          </div>
        )}
      </div>

      {/* Pay Scale Reference */}
      <div className="border-t pt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <PayScaleReference cadre={formData.cadre as Cadre} />
          <PayLookup cadre={formData.cadre as Cadre} />
        </div>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="bg-yellow-50 p-4 rounded-lg">
        <h3 className="font-semibold text-yellow-800 mb-2">Step 3: Increment History</h3>
        <p className="text-sm text-yellow-600">Enter increment details from Service Register. This will be used to verify pay progression.</p>
      </div>

      <IncrementHistoryTable
        history={formData.incrementHistory || []}
        onChange={handleIncrementHistoryChange}
      />

      {calculatedData && (
        <div className="bg-gray-50 p-4 rounded-lg mt-4">
          <h4 className="font-semibold text-gray-800 mb-3">Calculated Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Completion Date:</span>
              <span className="ml-2 font-medium">{formatDate(calculatedData.completionDate)}</span>
            </div>
            <div>
              <span className="text-gray-600">Effective Date:</span>
              <span className="ml-2 font-medium">{formatDate(calculatedData.effectiveDate)}</span>
            </div>
            <div>
              <span className="text-gray-600">Current Pay:</span>
              <span className="ml-2 font-medium">₹{(formData.currentPay || 0).toLocaleString('en-IN')}/-</span>
            </div>
            <div>
              <span className="text-gray-600">Fixed Pay (after increment):</span>
              <span className="ml-2 font-medium text-green-700">₹{calculatedData.fixedPay.toLocaleString('en-IN')}/-</span>
            </div>
          </div>

          {calculatedData.futureIncrements.length > 0 && (
            <div className="mt-4">
              <h5 className="font-medium text-gray-700 mb-2">Future Increments:</h5>
              <table className="w-full text-sm border">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border px-2 py-1">S.No</th>
                    <th className="border px-2 py-1">Present Pay</th>
                    <th className="border px-2 py-1">Future Pay</th>
                    <th className="border px-2 py-1">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {calculatedData.futureIncrements.map((inc, idx) => (
                    <tr key={idx}>
                      <td className="border px-2 py-1 text-center">{idx + 1}</td>
                      <td className="border px-2 py-1 text-right">₹{inc.presentPay.toLocaleString('en-IN')}/-</td>
                      <td className="border px-2 py-1 text-right">₹{inc.futurePay.toLocaleString('en-IN')}/-</td>
                      <td className="border px-2 py-1 text-center">{formatDate(inc.date)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <div className="bg-purple-50 p-4 rounded-lg">
        <h3 className="font-semibold text-purple-800 mb-2">Step 4: Reference & Approval Details</h3>
        <p className="text-sm text-purple-600">Enter proposal reference and approving authority details.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormInput
          label="Proposal Letter/Reference No."
          name="proposalLetterNo"
          value={formData.proposalLetterNo || ''}
          onChange={handleInputChange}
          placeholder="e.g., Tahsildar, Allur letter in Rc.A/219/2026"
          required
        />

        <FormInput
          label="Proposal Letter Date"
          name="proposalLetterDate"
          type="date"
          value={formData.proposalLetterDate || ''}
          onChange={handleInputChange}
          required
        />

        <FormInput
          label="Collector Name & Designation"
          name="collectorName"
          value={formData.collectorName || ''}
          onChange={handleInputChange}
          placeholder="e.g., SRI HIMANSHU SHUKLA, I.A.S."
          required
        />

        {formData.cadre === 'Deputy Tahsildar' && (
          <FormInput
            label="Joint Collector Name & Designation"
            name="jointCollectorName"
            value={formData.jointCollectorName || ''}
            onChange={handleInputChange}
            placeholder="e.g., SRI MOGILI VENKATESWARLU., I.A.S."
          />
        )}

        <FormInput
          label="DRO Name (if applicable)"
          name="droName"
          value={formData.droName || ''}
          onChange={handleInputChange}
          placeholder="District Revenue Officer Name"
        />

        <FormInput
          label="Approved By Name"
          name="approvedByName"
          value={formData.approvedByName || ''}
          onChange={handleInputChange}
          placeholder="Name of approving officer"
        />

        <FormInput
          label="Approval Date"
          name="approvedDate"
          type="date"
          value={formData.approvedDate || ''}
          onChange={handleInputChange}
        />
      </div>
    </div>
  );

  const renderStep5 = () => {
    const { years, scaleName, scaleAbbr } = getIncrementTypeDescription(formData.incrementType);
    
    return (
      <div className="space-y-6">
        <div className="bg-indigo-50 p-4 rounded-lg">
          <h3 className="font-semibold text-indigo-800 mb-2">Step 5: Review & Generate Documents</h3>
          <p className="text-sm text-indigo-600">Review the details and generate Office Note and Proceedings.</p>
        </div>

        <div className="bg-white border rounded-lg p-6">
          <h4 className="font-semibold text-lg mb-4 border-b pb-2">Summary</h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <h5 className="font-medium text-gray-800">Employee Details</h5>
              <p><span className="text-gray-500">Name:</span> {formData.gender === 'male' ? 'Sri' : 'Smt'} {formData.name}</p>
              <p><span className="text-gray-500">Cadre:</span> {formData.cadre}</p>
              <p><span className="text-gray-500">Office:</span> O/o {formData.office}, {formData.mandal} Mandal</p>
              <p><span className="text-gray-500">District:</span> {formData.district}</p>
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-gray-800">Increment Details</h5>
              <p><span className="text-gray-500">Type:</span> {years} Years - {scaleName} ({scaleAbbr})</p>
              <p><span className="text-gray-500">Joining Date:</span> {formData.joiningDate ? formatDate(formData.joiningDate) : '-'}</p>
              {calculatedData && (
                <>
                  <p><span className="text-gray-500">Completion Date:</span> {formatDate(calculatedData.completionDate)}</p>
                  <p><span className="text-gray-500">Effective Date:</span> {formatDate(calculatedData.effectiveDate)}</p>
                </>
              )}
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-gray-800">Pay Details</h5>
              <p><span className="text-gray-500">Current Pay:</span> ₹{(formData.currentPay || 0).toLocaleString('en-IN')}/-</p>
              {calculatedData && (
                <p><span className="text-gray-500">Fixed Pay:</span> <span className="text-green-700 font-medium">₹{calculatedData.fixedPay.toLocaleString('en-IN')}/-</span></p>
              )}
            </div>

            <div className="space-y-2">
              <h5 className="font-medium text-gray-800">Status</h5>
              <p><span className="text-gray-500">EOL:</span> {formData.hasEOL ? `Yes (${formData.eolDays} days)` : 'No'}</p>
              <p><span className="text-gray-500">Disciplinary Cases:</span> {formData.hasDisciplinaryCase ? 'Yes' : 'No'}</p>
            </div>
          </div>

          <div className="mt-6 flex gap-4">
            <button
              onClick={generateDocuments}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium shadow-md"
            >
              📄 Generate Documents
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-800 to-blue-600 text-white p-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold">Special Increment Document Generator</h1>
              <p className="text-blue-100 mt-1">
                Generate Office Notes and Proceedings for 6/12/18/24 Years Special Increments
              </p>
            </div>
            <div className="flex gap-2 items-center">
              {/* Offline Indicator */}
              {!isOnline && (
                <span className="px-3 py-1 bg-yellow-500 text-yellow-900 rounded-full text-xs font-medium">
                  📴 Offline Mode
                </span>
              )}
              
              {/* Save Draft Button */}
              <button
                onClick={handleSaveDraft}
                className="px-3 py-2 bg-green-600 hover:bg-green-700 rounded-lg text-sm flex items-center gap-1"
                title="Save as Draft"
              >
                💾 Save
              </button>

              {/* Drafts Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowDraftsMenu(!showDraftsMenu)}
                  className="px-3 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg text-sm flex items-center gap-1"
                >
                  📂 Drafts ({drafts.length})
                </button>
                {showDraftsMenu && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-lg z-20 text-gray-800 max-h-80 overflow-y-auto">
                    <div className="p-2">
                      <p className="text-xs text-gray-500 px-2 mb-2">Saved Drafts</p>
                      {drafts.length === 0 ? (
                        <p className="text-sm text-gray-400 px-2 py-4 text-center">No saved drafts</p>
                      ) : (
                        drafts.map((draft) => (
                          <div key={draft.key} className="flex items-center justify-between px-2 py-2 hover:bg-gray-100 rounded">
                            <button
                              onClick={() => handleLoadDraft(draft.key)}
                              className="flex-1 text-left"
                            >
                              <p className="text-sm font-medium">{draft.name}</p>
                              <p className="text-xs text-gray-500">
                                {new Date(draft.savedAt).toLocaleString()}
                              </p>
                            </button>
                            <button
                              onClick={() => handleDeleteDraft(draft.key)}
                              className="text-red-500 hover:text-red-700 px-2"
                              title="Delete"
                            >
                              🗑️
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Sample Data Menu */}
              <div className="relative">
                <button
                  onClick={() => setShowSampleMenu(!showSampleMenu)}
                  className="px-3 py-2 bg-blue-700 hover:bg-blue-800 rounded-lg text-sm flex items-center gap-1"
                >
                  📁 Samples
                </button>
                {showSampleMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg z-20 text-gray-800">
                    <div className="p-2">
                      <button
                        onClick={() => {
                          setFormData(sampleDataVRO);
                          setShowSampleMenu(false);
                          setStep(1);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-sm"
                      >
                        VRO - 6 Years (Sample)
                      </button>
                      <button
                        onClick={() => {
                          setFormData(sampleDataDeputyTahsildar);
                          setShowSampleMenu(false);
                          setStep(1);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-sm"
                      >
                        Deputy Tahsildar - 12 Years (Sample)
                      </button>
                      <hr className="my-2" />
                      <button
                        onClick={() => {
                          setFormData(initialFormData);
                          setShowSampleMenu(false);
                          setStep(1);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-sm text-red-600"
                      >
                        🗑️ Clear Form
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="bg-gray-100 px-6 py-4">
          <div className="flex justify-between items-center">
            {[1, 2, 3, 4, 5].map((s) => (
              <div key={s} className="flex items-center">
                <button
                  onClick={() => setStep(s)}
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-medium transition-colors
                    ${step === s 
                      ? 'bg-blue-600 text-white' 
                      : step > s 
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-300 text-gray-600'
                    }`}
                >
                  {step > s ? '✓' : s}
                </button>
                <span className={`ml-2 text-sm hidden md:inline ${step === s ? 'font-medium' : 'text-gray-500'}`}>
                  {s === 1 && 'Basic Info'}
                  {s === 2 && 'Service Details'}
                  {s === 3 && 'Increment History'}
                  {s === 4 && 'References'}
                  {s === 5 && 'Generate'}
                </span>
                {s < 5 && <div className="w-12 h-0.5 bg-gray-300 mx-2 hidden md:block" />}
              </div>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="p-6">
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}
          {step === 4 && renderStep4()}
          {step === 5 && renderStep5()}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 pt-4 border-t">
            <button
              onClick={() => setStep(Math.max(1, step - 1))}
              disabled={step === 1}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              ← Previous
            </button>
            
            {step < 5 ? (
              <button
                onClick={() => setStep(Math.min(5, step + 1))}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Next →
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* Document Previews */}
      {showOfficeNote && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-auto">
            <DocumentPreview
              title="Office Note"
              content={officeNoteContent}
              onDownload={() => downloadAsWord(officeNoteContent, `Office_Note_${formData.name}`)}
              onClose={() => setShowOfficeNote(false)}
            />
            <div className="mt-4">
              <button
                onClick={() => {
                  setShowOfficeNote(false);
                  setShowProceedings(true);
                }}
                className="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium"
              >
                View Proceedings →
              </button>
            </div>
          </div>
        </div>
      )}

      {showProceedings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-4xl max-h-[90vh] overflow-auto">
            <DocumentPreview
              title="Proceedings"
              content={proceedingsContent}
              onDownload={() => downloadAsWord(proceedingsContent, `Proceedings_${formData.name}`)}
              onClose={() => setShowProceedings(false)}
            />
            <div className="mt-4">
              <button
                onClick={() => {
                  setShowProceedings(false);
                  setShowOfficeNote(true);
                }}
                className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
              >
                ← View Office Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
