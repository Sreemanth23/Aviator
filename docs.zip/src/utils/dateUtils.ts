// Date utility functions

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

export function formatDateLong(date: string | Date): string {
  const d = new Date(date);
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

export function addDays(date: string | Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

export function addYears(date: string | Date, years: number): Date {
  const d = new Date(date);
  d.setFullYear(d.getFullYear() + years);
  return d;
}

export function subtractDays(date: string | Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() - days);
  return d;
}

export function daysBetween(date1: string | Date, date2: string | Date): number {
  const d1 = new Date(date1);
  const d2 = new Date(date2);
  const diffTime = Math.abs(d2.getTime() - d1.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function calculateCompletionDate(
  joiningDate: string,
  years: number,
  eolDays: number = 0
): Date {
  const completion = addYears(joiningDate, years);
  return addDays(completion, eolDays);
}

export function getIncrementMonth(joiningDate: string): number {
  const d = new Date(joiningDate);
  return d.getMonth() + 1; // 1-indexed month
}

export function getNextIncrementDate(joiningDate: string, afterDate: string): string {
  const joining = new Date(joiningDate);
  const after = new Date(afterDate);
  const incrementMonth = joining.getMonth();
  
  let year = after.getFullYear();
  if (after.getMonth() >= incrementMonth) {
    year++;
  }
  
  const nextIncrement = new Date(year, incrementMonth, 1);
  return nextIncrement.toISOString().split('T')[0];
}

export function calculateServiceYears(joiningDate: string, asOnDate: string, eolDays: number = 0): number {
  const joining = new Date(joiningDate);
  const asOn = new Date(asOnDate);
  
  let years = asOn.getFullYear() - joining.getFullYear();
  const monthDiff = asOn.getMonth() - joining.getMonth();
  const dayDiff = asOn.getDate() - joining.getDate();
  
  if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
    years--;
  }
  
  // Adjust for EOL days
  const effectiveYears = years - (eolDays / 365);
  return Math.floor(effectiveYears);
}

export function getPreviousDay(date: string): string {
  const d = new Date(date);
  d.setDate(d.getDate() - 1);
  return d.toISOString().split('T')[0];
}

export function getMonthName(monthNumber: number): string {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months[monthNumber - 1] || '';
}
