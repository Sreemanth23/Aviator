// Document generation utilities for Office Notes and Proceedings

import { EmployeeData, IncrementType } from '../types';
import { formatDate } from './dateUtils';
import { 
  calculateCompletionDate, 
  calculateFixedPay, 
  getScaleStrings, 
  getIncrementTypeDescription,
  generateFutureIncrements,
  formatPayWithRupees
} from './incrementCalculations';

// Get title/prefix based on gender
function getTitle(gender: 'male' | 'female'): string {
  return gender === 'male' ? 'Sri' : 'Smt';
}

function getPronoun(gender: 'male' | 'female'): { subject: string; object: string; possessive: string } {
  return gender === 'male' 
    ? { subject: 'He', object: 'him', possessive: 'his' }
    : { subject: 'She', object: 'her', possessive: 'her' };
}

// Get approving authority based on cadre
function getApprovingAuthority(cadre: string): string {
  switch (cadre) {
    case 'Tahsildar':
      return 'Collector & District Magistrate';
    case 'Deputy Tahsildar':
      return 'Joint Collector';
    case 'Village Revenue Officer':
    case 'Junior Assistant':
    case 'Senior Assistant':
    default:
      return 'District Revenue Officer';
  }
}

// Note: Increment history table formatting is handled in the form component

// Generate Office Note
export function generateOfficeNote(
  data: EmployeeData,
  incrementType: IncrementType
): string {
  const title = getTitle(data.gender);
  const pronouns = getPronoun(data.gender);
  const { years, scaleName, scaleAbbr } = getIncrementTypeDescription(incrementType);
  const authority = getApprovingAuthority(data.cadre);
  
  // Calculate dates
  const { completionDate, effectiveDate } = calculateCompletionDate(
    data.joiningDate,
    data.joiningSession,
    years,
    data.eolDays || 0
  );

  // Calculate pay
  const fixedPay = calculateFixedPay(data.currentPay, data.cadre, incrementType);
  const { currentScale, newScale } = getScaleStrings(data.cadre, incrementType);

  // Generate future increments
  const incrementMonth = new Date(data.joiningDate).getMonth() + 1;
  const futureIncrements = generateFutureIncrements(fixedPay, effectiveDate, data.cadre, incrementMonth, 5);

  // Build position string
  let positionString = `${title} ${data.name}, ${data.cadre}`;
  if (data.grade) positionString += `, Grade – ${data.grade}`;
  if (data.village) positionString += `, ${data.village}`;
  positionString += `, O/o ${data.office}, ${data.mandal} Mandal, ${data.district} District`;

  const officeNote = `OFFICE NOTE

Sub:-	Public Servants – ${data.district} District – ${data.cadre}s – ${positionString} - Completed ${years} years of service in the cadre of ${data.cadre} – Sanction of ${scaleName} (${scaleAbbr}) to the individual - Requested - Reg.

Ref:-	1. G.O.Ms.No.96, Finance (P.C.II) Department, dt.20.05.2011.
	2. G.O.Ms.No.68, Finance (HRM.V) Dept, Dt: 12.06.2015.
	3. GO.MS.No.1, Finance (PC-TA) Department, Dt:17.01.2022.
	4. ${data.proposalLetterNo}, dt:${formatDate(data.proposalLetterDate)}.

***//***

Submitted,

2) Kind attention is invited to the references cited.

3) It is submitted that, in reference 4th cited, ${data.cadre === 'Village Revenue Officer' ? 'the Tahsildar' : 'the individual'} has submitted a proposal for the sanction of ${scaleName} (${scaleAbbr}) to ${title} ${data.name} in the cadre of ${data.cadre}.

4) As verified from the Service Register of the individual, it has been noticed that the said individual was ${years === 6 ? 'appointed' : 'sanctioned Special Grade Post (6 years increment) and completed'} as ${data.cadre} vide Proceedings ${data.appointmentOrderNo}, dated: ${formatDate(data.appointmentOrderDate)}, and the individual joined duty on ${formatDate(data.joiningDate)} (${data.joiningSession}). ${pronouns.subject} has completed ${years} years of service/Incremental service as on ${formatDate(completionDate)} in the cadre of ${data.cadre} as detailed below:

[INCREMENT HISTORY TABLE - To be filled from Service Register]

5) The pay of the above individual is ${formatPayWithRupees(data.currentPay)} as on ${formatDate(completionDate)} in the time scale of ${currentScale}.

6) The above individual has completed ${years} years of incremental service from ${formatDate(data.joiningDate)} to ${formatDate(completionDate)}${data.hasEOL ? ` (postponed due to EOL for ${data.eolDays} days)` : ''} without any promotion. The Automatic Advancement Scheme issued in G.O.Ms.No. 96, Finance (P.C.II) Department, dated: 20.05.2011 has come into effect from 01-02-2010. Hence, the Automatic Advancement Scheme has to be sanctioned to the said individual from ${formatDate(effectiveDate)}, with the pay fixed at ${formatPayWithRupees(fixedPay)}.

${futureIncrements.length > 0 ? `Subsequently, the increments have been revised as shown below:
S.No\tPresent Pay\tFuture Pay\tRevised Increment
${futureIncrements.map((inc, idx) => `${idx + 1}\t${inc.presentPay.toLocaleString('en-IN')}\t${inc.futurePay.toLocaleString('en-IN')}\t${formatDate(inc.date)}`).join('\n')}
` : ''}

7) ${data.hasDisciplinaryCase ? data.disciplinaryCaseDetails : 'There are no charges pending against the individual, and they have not availed themselves of any type of leave.'}

8) If the ${authority} pleases, the ${scaleName} (${scaleAbbr}) may be sanctioned to ${positionString}, and ${pronouns.possessive} pay may be fixed at ${formatPayWithRupees(fixedPay)} w.e.f. ${formatDate(effectiveDate)} under FR.22 (a) (i) read with FR.31(2) in the ${scaleName} scale of ${newScale} in the cadre of ${data.cadre}.${futureIncrements.length > 0 ? ` Additionally, the annual periodical increment that was already sanctioned may be revised, raising ${pronouns.possessive} pay from ${formatPayWithRupees(futureIncrements[0]?.presentPay || fixedPay)} to ${formatPayWithRupees(futureIncrements[0]?.futurePay || fixedPay)} w.e.f. ${formatDate(futureIncrements[0]?.date || effectiveDate)} in the cadre of ${data.cadre}.` : ''}

9) Subject to approval on para - 8, draft proceedings put up below for approval.


							${authority}`;

  return officeNote;
}

// Generate Proceedings
export function generateProceedings(
  data: EmployeeData,
  incrementType: IncrementType
): string {
  const title = getTitle(data.gender);
  const pronouns = getPronoun(data.gender);
  const { years, scaleName, scaleAbbr } = getIncrementTypeDescription(incrementType);
  
  // Calculate dates
  const { completionDate, effectiveDate } = calculateCompletionDate(
    data.joiningDate,
    data.joiningSession,
    years,
    data.eolDays || 0
  );

  // Calculate pay
  const fixedPay = calculateFixedPay(data.currentPay, data.cadre, incrementType);
  const { currentScale, newScale } = getScaleStrings(data.cadre, incrementType);

  // Generate future increments
  const incrementMonth = new Date(data.joiningDate).getMonth() + 1;
  const futureIncrements = generateFutureIncrements(fixedPay, effectiveDate, data.cadre, incrementMonth, 5);

  // Build position string
  let positionString = `${title} ${data.name}, ${data.cadre}`;
  if (data.grade) positionString += `, Grade – ${data.grade}`;
  if (data.village) positionString += `, ${data.village}`;
  positionString += `, O/o ${data.office}, ${data.mandal} Mandal, ${data.district} District`;

  // Determine header based on cadre
  const isJointCollectorLevel = data.cadre === 'Deputy Tahsildar';

  let header = '';
  let footer = '';

  if (isJointCollectorLevel) {
    header = `PROCEEDINGS OF THE JOINT COLLECTOR & ADDITIONAL DISTRICT MAGISTRATE,
${data.district.toUpperCase()} DISTRICT,
PRESENT:: ${data.jointCollectorName || 'SRI _____________., I.A.S.,'}`;
    footer = `Joint Collector`;
  } else {
    header = `PROCEEDINGS OF THE COLLECTOR & DISTRICT MAGISTRATE,
${data.district.toUpperCase()} DISTRICT,
PRESENT:: ${data.collectorName}, ${data.collectorDesignation || 'I.A.S.'}`;
    footer = `For Collector`;
  }

  const proceedings = `${header}

                                                                             Dated: ${data.approvedDate ? formatDate(data.approvedDate) : '#ApprovedDate#'}

Sub:-	Public Servants – ${data.district} District – ${data.cadre}s – ${positionString} - Completed ${years} years of service in the cadre of ${data.cadre} – Sanction of ${scaleName} (${scaleAbbr}) to the individual - Sanction Orders - Issued.

Read:-	1. G.O.Ms.No.96, Finance (P.C.II) Department, dt.20.05.2011.
	2. G.O.Ms.No.68, Finance (HRM.V) Dept, Dt: 12.06.2015.
	3. GO.MS.No.1, Finance (PC-TA) Department, Dt:17.01.2022.
	4. ${data.proposalLetterNo}, dt:${formatDate(data.proposalLetterDate)}.

***//***

Order:

	In pursuance of the orders of the Government issued in the reference 1st read above, ${positionString} has completed ${years} years of ${years === 6 ? 'incremental' : ''} service in the cadre of ${data.cadre} from ${formatDate(data.joiningDate)} to ${formatDate(completionDate)}${data.hasEOL ? ` (postponed due to EOL for ${data.eolDays} days)` : ''} without getting promotion${data.hasEOL ? '' : `. The individual has not availed any E.O.L during the above period`}. Therefore the individual is hereby appointed in the ${scaleName} post with effect from ${formatDate(effectiveDate)}.

	The pay of the above individual as on ${formatDate(completionDate)} (i.e., the date of effect of Automatic Advancement Scheme vide G.O.Ms.No.96, Finance (P.C.II) Department, dt.20.05.2011) is at ${formatPayWithRupees(data.currentPay)} in the cadre of ${data.cadre} ${years > 6 ? '(Special Grade Post) ' : ''}in the time scale of pay of ${currentScale}.

	As per FR.22 (a) (i) and FR.31 (2), the pay of the individual is hereby fixed at ${formatPayWithRupees(fixedPay)} w.e.f. ${formatDate(effectiveDate)} in the ${scaleName} scale of pay ${newScale} in the cadre of ${data.cadre}.${futureIncrements.length > 0 ? ` Additionally, the annual periodical increment which was already sanctioned is hereby revised raising ${pronouns.possessive} pay from ${formatPayWithRupees(futureIncrements[0]?.presentPay || fixedPay)} to ${formatPayWithRupees(futureIncrements[0]?.futurePay || fixedPay)} w.e.f. ${formatDate(futureIncrements[0]?.date || effectiveDate)} in the cadre of ${data.cadre}.` : ''}

	If this pay fixation is found in excess in future to which ${pronouns.subject.toLowerCase()} is not eligible, the excess amount shall be recovered from ${pronouns.object} in lumpsum.

${data.approvedByName || '#ApprovedByName#'}
${footer}

To
The individual,
Copy to the Bill,
Copy to the SR.
Copy to the DTO/STO, ${data.district} District.`;

  return proceedings;
}

// Export to HTML for Word compatibility
export function generateHTMLDocument(content: string, title: string): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    body {
      font-family: 'Times New Roman', Times, serif;
      font-size: 12pt;
      line-height: 1.5;
      margin: 1in;
    }
    pre {
      font-family: 'Times New Roman', Times, serif;
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 10px 0;
    }
    td, th {
      border: 1px solid black;
      padding: 5px;
      text-align: left;
    }
  </style>
</head>
<body>
<pre>${content}</pre>
</body>
</html>`;
}

// Download as Word document
export function downloadAsWord(content: string, filename: string): void {
  const html = generateHTMLDocument(content, filename);
  const blob = new Blob([html], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filename}.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
