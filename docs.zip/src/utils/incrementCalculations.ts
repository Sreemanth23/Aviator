// Increment calculation utilities

import { Cadre, IncrementEntry, IncrementType } from '../types';
import { RPS2022_PAY_MATRIX, RPS2022_SCALES } from '../data/payScales';
import { addYears, addDays } from './dateUtils';

export interface IncrementCalculationResult {
  completionDate: string;
  effectiveDate: string;
  currentPayAsOnCompletion: number;
  fixedPay: number;
  futureIncrements: Array<{
    presentPay: number;
    futurePay: number;
    date: string;
  }>;
  normalScale: string;
  specialScale: string;
}

// Calculate the completion date considering EOL
export function calculateCompletionDate(
  joiningDate: string,
  joiningSession: 'FN' | 'AN',
  years: number,
  eolDays: number = 0
): { completionDate: string; effectiveDate: string } {
  let startDate = new Date(joiningDate);
  
  // If joined in AN, start counting from next day
  if (joiningSession === 'AN') {
    startDate = addDays(startDate, 1);
  }
  
  // Add years
  let completionDate = addYears(startDate, years);
  
  // Subtract one day (completion is day before the anniversary)
  completionDate = addDays(completionDate, -1);
  
  // Add EOL days if any
  if (eolDays > 0) {
    completionDate = addDays(completionDate, eolDays);
  }
  
  // Effective date is the next day
  const effectiveDate = addDays(completionDate, 1);
  
  return {
    completionDate: completionDate.toISOString().split('T')[0],
    effectiveDate: effectiveDate.toISOString().split('T')[0]
  };
}

// Get pay on a specific date from increment history
export function getPayOnDate(
  incrementHistory: IncrementEntry[],
  asOnDate: string,
  initialPay: number
): number {
  const targetDate = new Date(asOnDate);
  let currentPay = initialPay;
  
  for (const increment of incrementHistory) {
    const incDate = new Date(increment.effectiveDate);
    if (incDate <= targetDate) {
      currentPay = increment.toPay;
    }
  }
  
  return currentPay;
}

// Calculate fixed pay after special increment
export function calculateFixedPay(currentPay: number, cadre: Cadre, _incrementType: IncrementType): number {
  const matrix = RPS2022_PAY_MATRIX[cadre];
  
  // Find current position in matrix
  let currentIndex = matrix.indexOf(currentPay);
  
  if (currentIndex === -1) {
    // Find nearest higher value
    for (let i = 0; i < matrix.length; i++) {
      if (matrix[i] >= currentPay) {
        currentIndex = i;
        break;
      }
    }
    if (currentIndex === -1) {
      currentIndex = matrix.length - 1;
    }
  }
  
  // Move to next pay in scale (one increment benefit)
  const newIndex = Math.min(currentIndex + 1, matrix.length - 1);
  return matrix[newIndex];
}

// Generate future increment table
export function generateFutureIncrements(
  fixedPay: number,
  effectiveDate: string,
  cadre: Cadre,
  incrementMonth: number,
  numberOfIncrements: number = 5
): Array<{ presentPay: number; futurePay: number; date: string }> {
  const matrix = RPS2022_PAY_MATRIX[cadre];
  const result: Array<{ presentPay: number; futurePay: number; date: string }> = [];
  
  let currentPay = fixedPay;
  const effectiveDateObj = new Date(effectiveDate);
  let currentYear = effectiveDateObj.getFullYear();
  
  // If effective date is after increment month, start from next year
  if (effectiveDateObj.getMonth() + 1 > incrementMonth) {
    currentYear++;
  }
  
  for (let i = 0; i < numberOfIncrements; i++) {
    const currentIndex = matrix.indexOf(currentPay);
    if (currentIndex === -1 || currentIndex >= matrix.length - 1) break;
    
    const nextPay = matrix[currentIndex + 1];
    const incrementDate = new Date(currentYear + i, incrementMonth - 1, 1);
    
    // Only add if increment date is after effective date
    if (incrementDate > effectiveDateObj) {
      result.push({
        presentPay: currentPay,
        futurePay: nextPay,
        date: incrementDate.toISOString().split('T')[0]
      });
      currentPay = nextPay;
    } else {
      // Adjust to next cycle
      i--;
      currentYear++;
      if (result.length === 0) continue;
    }
  }
  
  return result;
}

// Get scale string based on increment type and cadre
export function getScaleStrings(
  cadre: Cadre,
  incrementType: IncrementType
): { currentScale: string; newScale: string } {
  const scales = RPS2022_SCALES[cadre];
  
  switch (incrementType) {
    case '6':
      return {
        currentScale: scales.normal.scaleString,
        newScale: scales.special.scaleString
      };
    case '12':
      return {
        currentScale: scales.special.scaleString,
        newScale: scales.sppIA.scaleString
      };
    case '18':
      return {
        currentScale: scales.sppIA.scaleString,
        newScale: scales.sppIA.scaleString // SPP-IB would be here
      };
    case '24':
      return {
        currentScale: scales.sppIA.scaleString,
        newScale: scales.sppIA.scaleString // SPP-II would be here
      };
    default:
      return {
        currentScale: scales.normal.scaleString,
        newScale: scales.special.scaleString
      };
  }
}

// Get increment type description
export function getIncrementTypeDescription(incrementType: IncrementType): {
  years: number;
  scaleName: string;
  scaleAbbr: string;
} {
  switch (incrementType) {
    case '6':
      return {
        years: 6,
        scaleName: 'Special Grade Post',
        scaleAbbr: 'SGP'
      };
    case '12':
      return {
        years: 12,
        scaleName: 'Special Promotion Post Scale - IA',
        scaleAbbr: 'SPP-IA'
      };
    case '18':
      return {
        years: 18,
        scaleName: 'Special Promotion Post Scale - IB',
        scaleAbbr: 'SPP-IB'
      };
    case '24':
      return {
        years: 24,
        scaleName: 'Special Promotion Post Scale - II',
        scaleAbbr: 'SPP-II'
      };
    default:
      return {
        years: 6,
        scaleName: 'Special Grade Post',
        scaleAbbr: 'SGP'
      };
  }
}

// Calculate all increment details
export function calculateIncrementDetails(
  joiningDate: string,
  joiningSession: 'FN' | 'AN',
  currentPay: number,
  cadre: Cadre,
  incrementType: IncrementType,
  eolDays: number = 0,
  incrementHistory: IncrementEntry[] = []
): IncrementCalculationResult {
  const years = parseInt(incrementType);
  
  // Calculate completion and effective dates
  const { completionDate, effectiveDate } = calculateCompletionDate(
    joiningDate,
    joiningSession,
    years,
    eolDays
  );
  
  // Get pay as on completion date
  const payAsOnCompletion = incrementHistory.length > 0
    ? getPayOnDate(incrementHistory, completionDate, currentPay)
    : currentPay;
  
  // Calculate fixed pay
  const fixedPay = calculateFixedPay(payAsOnCompletion, cadre, incrementType);
  
  // Get scales
  const { currentScale, newScale } = getScaleStrings(cadre, incrementType);
  
  // Get increment month from joining date
  const incrementMonth = new Date(joiningDate).getMonth() + 1;
  
  // Generate future increments
  const futureIncrements = generateFutureIncrements(
    fixedPay,
    effectiveDate,
    cadre,
    incrementMonth,
    5
  );
  
  return {
    completionDate,
    effectiveDate,
    currentPayAsOnCompletion: payAsOnCompletion,
    fixedPay,
    futureIncrements,
    normalScale: currentScale,
    specialScale: newScale
  };
}

// Format pay amount with commas
export function formatPay(amount: number): string {
  return amount.toLocaleString('en-IN');
}

// Format pay with Rs. prefix
export function formatPayWithRupees(amount: number): string {
  return `Rs.${formatPay(amount)}/-`;
}
