// Types for Special Increment Document Generator

export type Gender = 'male' | 'female';

export type Cadre = 
  | 'Village Revenue Officer'
  | 'Junior Assistant'
  | 'Senior Assistant'
  | 'Deputy Tahsildar'
  | 'Tahsildar';

export type IncrementType = '6' | '12' | '18' | '24';

export type PRCVersion = '2010' | '2015' | '2022';

export interface PayScale {
  min: number;
  max: number;
  increments: number[];
  scaleString: string;
}

export interface IncrementEntry {
  incrementNo: number;
  fromPay: number;
  toPay: number;
  effectiveDate: string;
  pageNo: string;
  srVolume: string;
  remarks?: string;
}

export interface EmployeeData {
  // Personal Details
  name: string;
  gender: Gender;
  cadre: Cadre;
  grade?: string;
  
  // Posting Details
  village?: string;
  office: string;
  mandal: string;
  district: string;
  
  // Service Details
  appointmentDate: string;
  appointmentOrderNo: string;
  appointmentOrderDate: string;
  joiningDate: string;
  joiningSession: 'FN' | 'AN';
  
  // Pay Details
  initialPay: number;
  currentPay: number;
  prcVersion: PRCVersion;
  
  // Increment History
  incrementHistory: IncrementEntry[];
  
  // 6 Years Details (if applicable)
  sixYearsCompletedDate?: string;
  sixYearsPayFixed?: number;
  
  // EOL Details
  hasEOL: boolean;
  eolFromDate?: string;
  eolToDate?: string;
  eolDays?: number;
  
  // Disciplinary Cases
  hasDisciplinaryCase: boolean;
  disciplinaryCaseDetails?: string;
  
  // Reference Details
  proposalLetterNo: string;
  proposalLetterDate: string;
  
  // Approving Authority
  approvedByName: string;
  approvedByDesignation: string;
  approvedDate: string;
  
  // District Officials
  collectorName: string;
  collectorDesignation: string;
  jointCollectorName?: string;
  droName?: string;
}

export interface FormState extends Partial<EmployeeData> {
  incrementType: IncrementType;
  step: number;
}

export interface GeneratedDocument {
  officeNote: string;
  proceedings: string;
}
